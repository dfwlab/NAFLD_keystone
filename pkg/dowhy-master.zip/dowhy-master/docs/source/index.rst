.. dowhy documentation master file, created by
   sphinx-quickstart on Tue Mar 13 14:48:10 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


.. include:: ../../README.rst

.. toctree::
   :maxdepth: 4
   :caption: Contents:
   
   readme
   do_why_simple_example
   do_why_estimation_methods
   do_why_refutation_methods
   load_graph_example
   do_why_confounder_example
   dowhy_lalonde_example
   code_repo
   dowhy
   modules

   


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
